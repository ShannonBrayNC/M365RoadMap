git add . git commit -m "Debugging the final report" --no-verify git push
