# Roadmap Report
_Generated 2025-08-16 15:07 UTC_

**Cloud filter:** General

---

## Table of Contents
- [[497910]](#id-497910)
- [[4710]](#id-4710)
- [[5000]](#id-5000)


### <a id="id-497910"></a> **[497910]**
[Roadmap](https://www.microsoft.com/microsoft-365/roadmap?filters=&searchterms=497910)

**Summary**
> (summary pending)

**What’s changing**
> (details pending)

**Impact and rollout**
> (impact pending)

**Action items**
> (actions pending)

---

### <a id="id-4710"></a> **[4710]**
[Roadmap](https://www.microsoft.com/microsoft-365/roadmap?filters=&searchterms=4710)

**Summary**
> (summary pending)

**What’s changing**
> (details pending)

**Impact and rollout**
> (impact pending)

**Action items**
> (actions pending)

---

### <a id="id-5000"></a> **[5000]**
[Roadmap](https://www.microsoft.com/microsoft-365/roadmap?filters=&searchterms=5000)

**Summary**
> (summary pending)

**What’s changing**
> (details pending)

**Impact and rollout**
> (impact pending)

**Action items**
> (actions pending)

---
